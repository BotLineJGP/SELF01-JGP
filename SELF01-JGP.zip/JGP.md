~TEAM•BOT•LINE•JGP~

LINE
https://line.me/ti/p/~cake.bot

เพจเฟสบุ๊ก
https://www.facebook.com/CreatorJGP/

IG
@cake.jadsada

YouTude
https://www.youtube.com/channel/UCHv9yCTgspTFOtULQu9X2wQ

🔽ไครใจดีเปร์นอยจิ🔽
Wallet:💵 095-896-6428

(ผมมันแค่มือสมักเล่น หัดทำBOTLINEพวกพี่ที่เทพๆอะสอนผมนอยดิ)